package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.openqa.selenium.support.ui.*;
import java.time.Duration;

public class LoginPage {

    WebDriver driver;
    WebDriverWait wait;

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    @FindBy(id="login2")
    WebElement loginLink;

    @FindBy(id="loginusername")
    WebElement username;

    @FindBy(id="loginpassword")
    WebElement password;

    @FindBy(xpath="//button[text()='Log in']")
    WebElement loginBtn;

    public void clickLogin() {
        loginLink.click();
    }

    public void enterUsername(String uname) {
        wait.until(ExpectedConditions.visibilityOf(username));
        username.sendKeys(uname);
    }

    public void enterPassword(String pwd) {
        password.sendKeys(pwd);
    }

    public void clickLoginButton() {
        loginBtn.click();
    }
}
