package stepdefinitions;

import io.cucumber.java.Before;
import io.cucumber.java.After;
import utilities.DriverFactory;

public class Hooks {

    @Before
    public void setup() {
        DriverFactory.initDriver();
        DriverFactory.getDriver().get("https://www.demoblaze.com/");
    }

    @After
    public void tearDown() {
        DriverFactory.quitDriver();
    }
}
