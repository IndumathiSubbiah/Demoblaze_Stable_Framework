package stepdefinitions;

import pages.LoginPage;
import utilities.DriverFactory;
import io.cucumber.java.en.*;

public class LoginSteps {

    LoginPage login;

    @Given("User is on homepage")
    public void user_on_homepage() {
        login = new LoginPage(DriverFactory.getDriver());
    }

    @When("User clicks Login link")
    public void click_login() {
        login.clickLogin();
    }

    @When("User enters username {string} and password {string}")
    public void enter_credentials(String uname, String pwd) {
        login.enterUsername(uname);
        login.enterPassword(pwd);
    }

    @Then("User clicks Login button")
    public void click_login_button() {
        login.clickLoginButton();
    }
}
