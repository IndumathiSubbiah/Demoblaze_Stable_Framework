Feature: Login functionality

  Scenario Outline: Verify login with valid credentials
    Given User is on homepage
    When User clicks Login link
    And User enters username "<username>" and password "<password>"
    Then User clicks Login button

    Examples:
      | username  | password  |
      | testuser1 | test123   |
      | testuser2 | test123   |
